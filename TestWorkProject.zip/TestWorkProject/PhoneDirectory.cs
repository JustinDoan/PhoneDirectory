﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWorkProject
{
    enum PhoneNumberStatus
    {
        Available = 0,
        Unavailable = 1
    }
    class PhoneDirectory
    {

        List<PhoneNumber> PhoneNumbers;

        public PhoneDirectory()
        {
             PhoneNumbers = new List<PhoneNumber>() {new PhoneNumber(1), new PhoneNumber(2) , new PhoneNumber(3) };
        }


        public PhoneNumber Get()
        {
            //Get the first available number
            try
            {
                PhoneNumber availableNumber = PhoneNumbers.Where(x => x.Status == PhoneNumberStatus.Available).First();
                return availableNumber;
            } catch (InvalidOperationException) {
                //There were no available numbers to get
                throw new InvalidOperationException($"There were no available numbers in the Phone Directory.");
            }
            
        }
        public PhoneNumberStatus Check(int number)
        {
            try
            {
                PhoneNumber numberToCheck = PhoneNumbers.Where(x => x.Number == number).First();
                return numberToCheck.Status;
            } catch(InvalidOperationException)
            {
                //that number didn't exist
                throw new InvalidOperationException($"{number} did not exist in the Phone Directory.");
            }          
        }
        public void Release(int number)
        {
            try
            {
                PhoneNumber numberToCheck = PhoneNumbers.Where(x => x.Number == number).First();
                numberToCheck.Release();
            }
            catch (InvalidOperationException)
            {
                //that number didn't exist
                throw new InvalidOperationException($"{number} did not exist in the Phone Directory.");
            }




        }
    }
    class PhoneNumber
    {

        public PhoneNumberStatus Status { get; set; }
        public int Number { get; set; }

        public PhoneNumber(int number)
        {
            Number = number;
            Status  = PhoneNumberStatus.Available;
        }



        public void Release()
        {
            //First check if the number is not available
            if (Status == PhoneNumberStatus.Unavailable)
            {
                Status = PhoneNumberStatus.Available;
            }
        }



    }
}
