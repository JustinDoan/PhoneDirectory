﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWorkProject
{
    class Program
    {
        static void Main(string[] args)
        {

            PhoneDirectory directory = new PhoneDirectory();
            PhoneNumber phoneNumber = directory.Get();
            Console.WriteLine($"{phoneNumber.Number} was selected, it's status is {phoneNumber.Status}");
            phoneNumber = directory.Get();
            Console.WriteLine($"{phoneNumber.Number} was selected, it's status is {phoneNumber.Status}");
            phoneNumber = directory.Get();
            Console.WriteLine($"{phoneNumber.Number} was selected, it's status is {phoneNumber.Status}");
            phoneNumber = directory.Get();
            Console.WriteLine($"{phoneNumber.Number} was selected, it's status is {phoneNumber.Status}");
        }
    }
}
